/*
 * Copyright © WHATWG (Apple, Google, Mozilla, Microsoft).
 * Copyright 1998 - 2011 W3C.
 * WHATWG portions incorporated into source code: BSD 3-Clause License.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * W3C selector portions: W3C Software and Document License 2002.
 * This work (and included software, documentation such as READMEs, or other related items) is being provided by the copyright holders under the following license.
 * License
 * By obtaining, using and/or copying this work, you (the licensee) agree that you have read, understood, and will comply with the following terms and conditions.
 * Permission to copy, modify, and distribute this software and its documentation, with or without modification, for any purpose and without fee or royalty is hereby granted, provided that you include the following on ALL copies of the software and documentation or portions thereof, including modifications:
 * The full text of this NOTICE in a location viewable to users of the redistributed or derivative work.
 * Any pre-existing intellectual property disclaimers, notices, or terms and conditions. If none exist, the W3C Software Short Notice should be included (hypertext is preferred, text is permitted) within the body of any redistributed or derivative code.
 * Notice of any changes or modifications to the files, including the date changes were made. (We recommend you provide URIs to the location from which the code is derived.)
 * Disclaimers
 * THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.
 * COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF ANY USE OF THE SOFTWARE OR DOCUMENTATION.
 * The name and trademarks of copyright holders may NOT be used in advertising or publicity pertaining to the software without specific, written prior permission. Title to copyright in this software and any associated documentation will at all times remain with copyright holders.
 * 
 * Changes, 2026-10-28: select 252 names; preserve Graphviz legacy lang/rang values.
 * Data: https://html.spec.whatwg.org/entities.json
 * Selectors: https://www.w3.org/2003/entities/2007/xhtml1-{lat1,special,symbol}.ent
 */
/// @file
/// @ingroup common_utils
/*
 * Generated file - do not edit directly.
 *
 * This file was generated from:
 *       https://html.spec.whatwg.org/entities.json
 * by means of the script:
 *       entities.py
 */

#ifdef __cplusplus
extern "C" {
#endif

static const struct entities_s {
	char	*name;
	int	value;
} entities[] = {
	{"AElig", 198},
	{"Aacute", 193},
	{"Acirc", 194},
	{"Agrave", 192},
	{"Alpha", 913},
	{"Aring", 197},
	{"Atilde", 195},
	{"Auml", 196},
	{"Beta", 914},
	{"Ccedil", 199},
	{"Chi", 935},
	{"Dagger", 8225},
	{"Delta", 916},
	{"ETH", 208},
	{"Eacute", 201},
	{"Ecirc", 202},
	{"Egrave", 200},
	{"Epsilon", 917},
	{"Eta", 919},
	{"Euml", 203},
	{"Gamma", 915},
	{"Iacute", 205},
	{"Icirc", 206},
	{"Igrave", 204},
	{"Iota", 921},
	{"Iuml", 207},
	{"Kappa", 922},
	{"Lambda", 923},
	{"Mu", 924},
	{"Ntilde", 209},
	{"Nu", 925},
	{"OElig", 338},
	{"Oacute", 211},
	{"Ocirc", 212},
	{"Ograve", 210},
	{"Omega", 937},
	{"Omicron", 927},
	{"Oslash", 216},
	{"Otilde", 213},
	{"Ouml", 214},
	{"Phi", 934},
	{"Pi", 928},
	{"Prime", 8243},
	{"Psi", 936},
	{"Rho", 929},
	{"Scaron", 352},
	{"Sigma", 931},
	{"THORN", 222},
	{"Tau", 932},
	{"Theta", 920},
	{"Uacute", 218},
	{"Ucirc", 219},
	{"Ugrave", 217},
	{"Upsilon", 933},
	{"Uuml", 220},
	{"Xi", 926},
	{"Yacute", 221},
	{"Yuml", 376},
	{"Zeta", 918},
	{"aacute", 225},
	{"acirc", 226},
	{"acute", 180},
	{"aelig", 230},
	{"agrave", 224},
	{"alefsym", 8501},
	{"alpha", 945},
	{"amp", 38},
	{"and", 8743},
	{"ang", 8736},
	{"aring", 229},
	{"asymp", 8776},
	{"atilde", 227},
	{"auml", 228},
	{"bdquo", 8222},
	{"beta", 946},
	{"brvbar", 166},
	{"bull", 8226},
	{"cap", 8745},
	{"ccedil", 231},
	{"cedil", 184},
	{"cent", 162},
	{"chi", 967},
	{"circ", 710},
	{"clubs", 9827},
	{"cong", 8773},
	{"copy", 169},
	{"crarr", 8629},
	{"cup", 8746},
	{"curren", 164},
	{"dArr", 8659},
	{"dagger", 8224},
	{"darr", 8595},
	{"deg", 176},
	{"delta", 948},
	{"diams", 9830},
	{"divide", 247},
	{"eacute", 233},
	{"ecirc", 234},
	{"egrave", 232},
	{"empty", 8709},
	{"emsp", 8195},
	{"ensp", 8194},
	{"epsilon", 949},
	{"equiv", 8801},
	{"eta", 951},
	{"eth", 240},
	{"euml", 235},
	{"euro", 8364},
	{"exist", 8707},
	{"fnof", 402},
	{"forall", 8704},
	{"frac12", 189},
	{"frac14", 188},
	{"frac34", 190},
	{"frasl", 8260},
	{"gamma", 947},
	{"ge", 8805},
	{"gt", 62},
	{"hArr", 8660},
	{"harr", 8596},
	{"hearts", 9829},
	{"hellip", 8230},
	{"iacute", 237},
	{"icirc", 238},
	{"iexcl", 161},
	{"igrave", 236},
	{"image", 8465},
	{"infin", 8734},
	{"int", 8747},
	{"iota", 953},
	{"iquest", 191},
	{"isin", 8712},
	{"iuml", 239},
	{"kappa", 954},
	{"lArr", 8656},
	{"lambda", 955},
	{"lang", 9001},
	{"laquo", 171},
	{"larr", 8592},
	{"lceil", 8968},
	{"ldquo", 8220},
	{"le", 8804},
	{"lfloor", 8970},
	{"lowast", 8727},
	{"loz", 9674},
	{"lrm", 8206},
	{"lsaquo", 8249},
	{"lsquo", 8216},
	{"lt", 60},
	{"macr", 175},
	{"mdash", 8212},
	{"micro", 181},
	{"middot", 183},
	{"minus", 8722},
	{"mu", 956},
	{"nabla", 8711},
	{"nbsp", 160},
	{"ndash", 8211},
	{"ne", 8800},
	{"ni", 8715},
	{"not", 172},
	{"notin", 8713},
	{"nsub", 8836},
	{"ntilde", 241},
	{"nu", 957},
	{"oacute", 243},
	{"ocirc", 244},
	{"oelig", 339},
	{"ograve", 242},
	{"oline", 8254},
	{"omega", 969},
	{"omicron", 959},
	{"oplus", 8853},
	{"or", 8744},
	{"ordf", 170},
	{"ordm", 186},
	{"oslash", 248},
	{"otilde", 245},
	{"otimes", 8855},
	{"ouml", 246},
	{"para", 182},
	{"part", 8706},
	{"permil", 8240},
	{"perp", 8869},
	{"phi", 966},
	{"pi", 960},
	{"piv", 982},
	{"plusmn", 177},
	{"pound", 163},
	{"prime", 8242},
	{"prod", 8719},
	{"prop", 8733},
	{"psi", 968},
	{"quot", 34},
	{"rArr", 8658},
	{"radic", 8730},
	{"rang", 9002},
	{"raquo", 187},
	{"rarr", 8594},
	{"rceil", 8969},
	{"rdquo", 8221},
	{"real", 8476},
	{"reg", 174},
	{"rfloor", 8971},
	{"rho", 961},
	{"rlm", 8207},
	{"rsaquo", 8250},
	{"rsquo", 8217},
	{"sbquo", 8218},
	{"scaron", 353},
	{"sdot", 8901},
	{"sect", 167},
	{"shy", 173},
	{"sigma", 963},
	{"sigmaf", 962},
	{"sim", 8764},
	{"spades", 9824},
	{"sub", 8834},
	{"sube", 8838},
	{"sum", 8721},
	{"sup", 8835},
	{"sup1", 185},
	{"sup2", 178},
	{"sup3", 179},
	{"supe", 8839},
	{"szlig", 223},
	{"tau", 964},
	{"there4", 8756},
	{"theta", 952},
	{"thetasym", 977},
	{"thinsp", 8201},
	{"thorn", 254},
	{"tilde", 732},
	{"times", 215},
	{"trade", 8482},
	{"uArr", 8657},
	{"uacute", 250},
	{"uarr", 8593},
	{"ucirc", 251},
	{"ugrave", 249},
	{"uml", 168},
	{"upsih", 978},
	{"upsilon", 965},
	{"uuml", 252},
	{"weierp", 8472},
	{"xi", 958},
	{"yacute", 253},
	{"yen", 165},
	{"yuml", 255},
	{"zeta", 950},
	{"zwj", 8205},
	{"zwnj", 8204},
};

#define ENTITY_NAME_LENGTH_MAX 8
#define NR_OF_ENTITIES (sizeof(entities) / sizeof(entities[0]))

#ifdef __cplusplus
}
#endif

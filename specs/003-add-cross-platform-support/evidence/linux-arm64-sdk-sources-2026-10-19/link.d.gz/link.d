dot: \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/920d1e37e43d8aeee0bd1e935b76a00d/crt1.o \
 /home/runner/work/_temp/twine-arm64-build/build/cmd/dot/CMakeFiles/dot.dir/dot.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/cmd/dot/CMakeFiles/dot.dir/dot_builtins.cpp.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/args.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/arrows.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/colxlate.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/ellipse.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/emit.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/geom.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/globals.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/htmllex.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/htmltable.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/input.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/labels.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/ns.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/output.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/pointset.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/postproc.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/psusershape.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/routespl.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/shapes.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/splines.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/taper.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/textspan.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/textspan_lut.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/timing.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/utils.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/htmlparse.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/pack/CMakeFiles/pack_obj.dir/ccomps.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/pack/CMakeFiles/pack_obj.dir/pack.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/fPQ.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/maze.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/ortho.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/partition.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/rawgraph.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/sgraph.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/trapezoid.c.o \
 /home/runner/work/_temp/twine-arm64-build/build/lib/cdt/libcdt.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/cgraph/libcgraph.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/gvc/libgvc.a \
 /home/runner/work/_temp/twine-arm64-build/build/plugin/core/libgvplugin_core.a \
 /home/runner/work/_temp/twine-arm64-build/build/plugin/dot_layout/libgvplugin_dot_layout.a \
 /home/runner/work/_temp/twine-arm64-build/build/plugin/neato_layout/libgvplugin_neato_layout.a \
 /home/runner/work/_temp/twine-arm64-build/build/plugin/vt/libgvplugin_vt.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/pathplan/libpathplan.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/xdot/libxdot.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/dotgen/libdotgen.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/circogen/libcircogen.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/fdpgen/libfdpgen.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/neatogen/libneatogen.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/osage/libosage.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/patchwork/libpatchwork.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/rbtree/librbtree.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/sparse/libsparse.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/twopigen/libtwopigen.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/common/libcommon.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/label/liblabel.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/pack/libpack.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/ortho/libortho.a \
 /home/runner/work/_temp/twine-arm64-build/build/lib/util/libutil.a \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/08d0342be54d0d4f8820c049755fa240/libc++abi.a \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/380f2059eb5ce1ded325d200e6973dff/libc++.a \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/9c95c2979b36850b1960c78a1f3aac25/libunwind.a \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libm.so.6 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libpthread.so.0 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libc.so.6 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libdl.so.2 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/librt.so.1 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libld.so.2 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libutil.so.1 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libresolv.so.2 \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/49eb586f19423c2a0ddf5e63e1147f98/libc_nonshared.a \
 /home/runner/work/_temp/twine-arm64-sdk/cache/o/82b5f871e567cea1112c0f528d5dd09e/libcompiler_rt.a

/home/runner/work/_temp/twine-arm64-sdk/cache/o/920d1e37e43d8aeee0bd1e935b76a00d/crt1.o:

/home/runner/work/_temp/twine-arm64-build/build/cmd/dot/CMakeFiles/dot.dir/dot.c.o:

/home/runner/work/_temp/twine-arm64-build/build/cmd/dot/CMakeFiles/dot.dir/dot_builtins.cpp.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/args.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/arrows.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/colxlate.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/ellipse.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/emit.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/geom.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/globals.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/htmllex.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/htmltable.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/input.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/labels.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/ns.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/output.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/pointset.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/postproc.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/psusershape.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/routespl.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/shapes.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/splines.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/taper.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/textspan.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/textspan_lut.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/timing.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/utils.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/CMakeFiles/common_obj.dir/htmlparse.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/pack/CMakeFiles/pack_obj.dir/ccomps.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/pack/CMakeFiles/pack_obj.dir/pack.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/fPQ.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/maze.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/ortho.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/partition.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/rawgraph.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/sgraph.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/CMakeFiles/ortho_obj.dir/trapezoid.c.o:

/home/runner/work/_temp/twine-arm64-build/build/lib/cdt/libcdt.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/cgraph/libcgraph.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/gvc/libgvc.a:

/home/runner/work/_temp/twine-arm64-build/build/plugin/core/libgvplugin_core.a:

/home/runner/work/_temp/twine-arm64-build/build/plugin/dot_layout/libgvplugin_dot_layout.a:

/home/runner/work/_temp/twine-arm64-build/build/plugin/neato_layout/libgvplugin_neato_layout.a:

/home/runner/work/_temp/twine-arm64-build/build/plugin/vt/libgvplugin_vt.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/pathplan/libpathplan.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/xdot/libxdot.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/dotgen/libdotgen.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/circogen/libcircogen.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/fdpgen/libfdpgen.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/neatogen/libneatogen.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/osage/libosage.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/patchwork/libpatchwork.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/rbtree/librbtree.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/sparse/libsparse.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/twopigen/libtwopigen.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/common/libcommon.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/label/liblabel.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/pack/libpack.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/ortho/libortho.a:

/home/runner/work/_temp/twine-arm64-build/build/lib/util/libutil.a:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/08d0342be54d0d4f8820c049755fa240/libc++abi.a:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/380f2059eb5ce1ded325d200e6973dff/libc++.a:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/9c95c2979b36850b1960c78a1f3aac25/libunwind.a:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libm.so.6:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libpthread.so.0:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libc.so.6:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libdl.so.2:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/librt.so.1:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libld.so.2:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libutil.so.1:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/171ad53e576c4bedebbc31d452b1e977/libresolv.so.2:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/49eb586f19423c2a0ddf5e63e1147f98/libc_nonshared.a:

/home/runner/work/_temp/twine-arm64-sdk/cache/o/82b5f871e567cea1112c0f528d5dd09e/libcompiler_rt.a:

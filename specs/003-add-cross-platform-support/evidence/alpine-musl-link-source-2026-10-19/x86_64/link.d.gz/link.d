dot: \
 /work/sdk/cache/o/ac098cab0ec2f540d5d5bc2cd7bd4ef7/crt1.o \
 /work/build/build/cmd/dot/CMakeFiles/dot.dir/dot.c.o \
 /work/build/build/cmd/dot/CMakeFiles/dot.dir/dot_builtins.cpp.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/args.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/arrows.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/colxlate.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/ellipse.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/emit.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/geom.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/globals.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/htmllex.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/htmltable.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/input.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/labels.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/ns.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/output.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/pointset.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/postproc.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/psusershape.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/routespl.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/shapes.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/splines.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/taper.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/textspan.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/textspan_lut.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/timing.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/utils.c.o \
 /work/build/build/lib/common/CMakeFiles/common_obj.dir/htmlparse.c.o \
 /work/build/build/lib/pack/CMakeFiles/pack_obj.dir/ccomps.c.o \
 /work/build/build/lib/pack/CMakeFiles/pack_obj.dir/pack.c.o \
 /work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/fPQ.c.o \
 /work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/maze.c.o \
 /work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/ortho.c.o \
 /work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/partition.c.o \
 /work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/rawgraph.c.o \
 /work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/sgraph.c.o \
 /work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/trapezoid.c.o \
 /work/build/build/lib/cdt/libcdt.a \
 /work/build/build/lib/cgraph/libcgraph.a \
 /work/build/build/lib/gvc/libgvc.a \
 /work/build/build/plugin/core/libgvplugin_core.a \
 /work/build/build/plugin/dot_layout/libgvplugin_dot_layout.a \
 /work/build/build/plugin/neato_layout/libgvplugin_neato_layout.a \
 /work/build/build/plugin/vt/libgvplugin_vt.a \
 /work/build/build/lib/pathplan/libpathplan.a \
 /work/build/build/lib/xdot/libxdot.a \
 /work/build/build/lib/dotgen/libdotgen.a \
 /work/build/build/lib/circogen/libcircogen.a \
 /work/build/build/lib/fdpgen/libfdpgen.a \
 /work/build/build/lib/neatogen/libneatogen.a \
 /work/build/build/lib/osage/libosage.a \
 /work/build/build/lib/patchwork/libpatchwork.a \
 /work/build/build/lib/rbtree/librbtree.a \
 /work/build/build/lib/sparse/libsparse.a \
 /work/build/build/lib/twopigen/libtwopigen.a \
 /work/build/build/lib/common/libcommon.a \
 /work/build/build/lib/label/liblabel.a \
 /work/build/build/lib/pack/libpack.a \
 /work/build/build/lib/ortho/libortho.a \
 /work/build/build/lib/util/libutil.a \
 /work/sdk/cache/o/7ec65b7ae73ad61ffa602c15c425b647/libc++abi.a \
 /work/sdk/cache/o/b052718ca0d74457213f2e61b9c1fdb3/libc++.a \
 /work/sdk/cache/o/3acbd874bd0801120ec92807d11015af/libunwind.a \
 /work/sdk/cache/o/026d48ae992764c2befb5087c6090344/libc.a \
 /work/sdk/cache/o/bfc52f89c10b487b178076e8a9a2a50a/libzigc.a \
 /work/sdk/cache/o/d2a14289a5e4659a5e02131c07ce703e/libcompiler_rt.a

/work/sdk/cache/o/ac098cab0ec2f540d5d5bc2cd7bd4ef7/crt1.o:

/work/build/build/cmd/dot/CMakeFiles/dot.dir/dot.c.o:

/work/build/build/cmd/dot/CMakeFiles/dot.dir/dot_builtins.cpp.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/args.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/arrows.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/colxlate.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/ellipse.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/emit.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/geom.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/globals.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/htmllex.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/htmltable.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/input.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/labels.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/ns.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/output.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/pointset.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/postproc.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/psusershape.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/routespl.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/shapes.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/splines.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/taper.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/textspan.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/textspan_lut.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/timing.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/utils.c.o:

/work/build/build/lib/common/CMakeFiles/common_obj.dir/htmlparse.c.o:

/work/build/build/lib/pack/CMakeFiles/pack_obj.dir/ccomps.c.o:

/work/build/build/lib/pack/CMakeFiles/pack_obj.dir/pack.c.o:

/work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/fPQ.c.o:

/work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/maze.c.o:

/work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/ortho.c.o:

/work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/partition.c.o:

/work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/rawgraph.c.o:

/work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/sgraph.c.o:

/work/build/build/lib/ortho/CMakeFiles/ortho_obj.dir/trapezoid.c.o:

/work/build/build/lib/cdt/libcdt.a:

/work/build/build/lib/cgraph/libcgraph.a:

/work/build/build/lib/gvc/libgvc.a:

/work/build/build/plugin/core/libgvplugin_core.a:

/work/build/build/plugin/dot_layout/libgvplugin_dot_layout.a:

/work/build/build/plugin/neato_layout/libgvplugin_neato_layout.a:

/work/build/build/plugin/vt/libgvplugin_vt.a:

/work/build/build/lib/pathplan/libpathplan.a:

/work/build/build/lib/xdot/libxdot.a:

/work/build/build/lib/dotgen/libdotgen.a:

/work/build/build/lib/circogen/libcircogen.a:

/work/build/build/lib/fdpgen/libfdpgen.a:

/work/build/build/lib/neatogen/libneatogen.a:

/work/build/build/lib/osage/libosage.a:

/work/build/build/lib/patchwork/libpatchwork.a:

/work/build/build/lib/rbtree/librbtree.a:

/work/build/build/lib/sparse/libsparse.a:

/work/build/build/lib/twopigen/libtwopigen.a:

/work/build/build/lib/common/libcommon.a:

/work/build/build/lib/label/liblabel.a:

/work/build/build/lib/pack/libpack.a:

/work/build/build/lib/ortho/libortho.a:

/work/build/build/lib/util/libutil.a:

/work/sdk/cache/o/7ec65b7ae73ad61ffa602c15c425b647/libc++abi.a:

/work/sdk/cache/o/b052718ca0d74457213f2e61b9c1fdb3/libc++.a:

/work/sdk/cache/o/3acbd874bd0801120ec92807d11015af/libunwind.a:

/work/sdk/cache/o/026d48ae992764c2befb5087c6090344/libc.a:

/work/sdk/cache/o/bfc52f89c10b487b178076e8a9a2a50a/libzigc.a:

/work/sdk/cache/o/d2a14289a5e4659a5e02131c07ce703e/libcompiler_rt.a:
